<?php

namespace App\Http\Controllers;

use App\Http\DataLayer\OtherPaymentDataLayer;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
// use App\Services\SmsService;
// use App\Services\Whatsapp;

class OtherPaymentController extends Controller
{
    protected $otherPaymentDL;
    public function __construct(OtherPaymentDataLayer $otherPaymentDL)
    {
        $this->otherPaymentDL = $otherPaymentDL;
    }
    
    public function index()
    {
        //
    }
    
    public function create()
    {
        //
    }
    
    public function store(Request $request)
    {
        // dd($request);
        try {
            $dataObj = $this->otherPaymentDL->insert($request);
            // dd($dataObj);
            
            // $smsService = new SmsService();
            // $whatsapp = new Whatsapp();
            
            // $amount = trim($request['advance']) !== '' ? trim($request['advance']) : trim($request['discount']);
            // $amountType = trim($request['advance']) !== '' ? 'advance' : 'discount';
            
            // $text = "Your paying amount Rs.".$amount." was Successful. Thank you for contacting Power Smile Dental Care. For more Information call 0705000100.";

            // if ($amountType == 'discount') {
            //     $text = "Your discount amount Rs.".$amount." was Successful. Thank you for contacting Power Smile Dental Care. For more Information call 0705000100.";
            // }
            
            // $smsService->sendSms($request->patient_id,$text);
            
            $successMessage = ($dataObj->payment_type == 'ADVANCE') ? 'Advance Payment saved successfully' : 'Discount saved successfully';

            return redirect()->route('invoice', ['patient_id' => $dataObj->patient_id])->with('success', $successMessage);
        } catch (ModelNotFoundException $ex) {
            if ($ex instanceof ModelNotFoundException) {
                return response()->view('errors.' . '404');
            }
        }
    }
    
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $dataObj = $this->otherPaymentDL->delete($id);
            return redirect()->back()->with('success', 'deleted Successfully');
        } catch (ModelNotFoundException $ex) {
            if ($ex instanceof ModelNotFoundException) {
                return response()->view('errors.' . '404');
            }
        }
    }
}
