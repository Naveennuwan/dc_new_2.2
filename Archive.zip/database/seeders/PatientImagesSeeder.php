<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\PatientImage;

class PatientImagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $Images = [
            //[1515, 5579, 'dYGUCDAZCmIh.jpg', 1, 1, 5]
        ];

        foreach ($Images as $row) {
            PatientImage::create([
                'patient_id' => $row[1],
                'image' => $row[2],
                'center_id' => $row[3],
                'isDisplay' => $row[4],
                'created_by' => $row[5],
            ]);
        }
    }
}
