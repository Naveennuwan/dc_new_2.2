<?php
    $price = 0;
    $levels = $template->priceLevels ?? collect();

    if ($levels->count() === 1) {

        $price = $levels->first()->price;

    } elseif ($levels->count() >= 2) {

        if (empty($patientDetails) || empty($patientDetails->created_at)) {

            $price = optional($levels->sortByDesc('effective_from')->first())->price ?? 0;

        } else {

            $nextPrice = $levels
                ->sortByDesc('effective_from')
                ->first(function ($item) use ($patientDetails) {
                    return $item->effective_from->lte($patientDetails->created_at);
                });

            $price = $nextPrice ? $nextPrice->price : 0;
        }
    }
?>

<button type="button"
    class="<?php echo e($btnClass ?? 'modern-btn'); ?>"
    style="width: <?php echo e($width ?? '230px'); ?>; height: 30px; font-size: 0.8rem;"
    onclick="handleButtonClick('<?php echo e($template->id); ?>')"
    data-price="<?php echo e($price); ?>"
    data-name="<?php echo e($template->name); ?>">
    <?php echo e($template->name); ?>

</button><?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/dashboard/template_button.blade.php ENDPATH**/ ?>