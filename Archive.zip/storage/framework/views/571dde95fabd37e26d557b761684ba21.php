<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="name" class="form-label col-3 col-sm-3 col-md-4">Name
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="name" name="name" placeholder="Name"
                    value="<?php echo e(Request::old('name', $dataObj->name ?? '')); ?>" maxlength="255">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <div class="input-group-prepend">
                <div class="input-group-text">
                    <input type="checkbox" id="isDisplay" name="isDisplay" value="1"
                        <?php echo e(Request::old('isDisplay', isset($dataObj) && $dataObj->isDisplay ? '1' : '') == '1' ? 'checked' : ''); ?>>
                </div>
            </div>
            <label for="isDisplay" class="form-label col-3 col-sm-3 col-md-4">Display</label>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="patient_nic_no" class="form-label col-3 col-sm-3 col-md-4">Nic No.
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
                <input type="text" class="form-control <?php $__errorArgs = ['patient_nic_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="patient_nic_no" name="patient_nic_no" placeholder="Nic No."
                value="<?php echo e(Request::old('patient_nic_no', $dataObj->patient_nic_no ?? '')); ?>" maxlength="255">
                <?php $__errorArgs = ['patient_nic_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="patient_incharge" class="form-label col-3 col-sm-3 col-md-4">Patient incharge</label>
            <div class="col-9 col-sm-9 col-md-8">
                <input type="text" class="form-control <?php $__errorArgs = ['patient_incharge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="patient_incharge" name="patient_incharge" placeholder="Patient incharge"
                    value="<?php echo e(Request::old('patient_incharge', $dataObj->patient_incharge ?? '')); ?>" maxlength="255">
                <?php $__errorArgs = ['patient_incharge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="patient_address" class="form-label col-3 col-sm-3 col-md-4">Address
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
                <input type="text" class="form-control <?php $__errorArgs = ['patient_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="patient_address" name="patient_address" placeholder="Address"
                    value="<?php echo e(Request::old('patient_address', $dataObj->patient_address ?? '')); ?>" maxlength="255">
                <?php $__errorArgs = ['patient_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="patient_contact_no" class="form-label col-3 col-sm-3 col-md-4">Contact No
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
                <input type="text" class="form-control <?php $__errorArgs = ['patient_contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="patient_contact_no" name="patient_contact_no" placeholder="Contact No"
                    value="<?php echo e(Request::old('patient_contact_no', $dataObj->patient_contact_no ?? '')); ?>" maxlength="11" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                <?php $__errorArgs = ['patient_contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="patient_gender" class="form-label col-3 col-sm-3 col-md-4">Gender
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
            <select
                    class="js-example-basic-single form-control <?php $__errorArgs = ['patient_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="patient_gender" name="patient_gender">
                    <option value="" selected>select Gender</option>
                    <option
                        <?php echo e(old('patient_gender', isset($dataObj) && $dataObj->patient_gender == "Male" ? "Male" : '') == "Male" ? 'selected' : ''); ?>

                        value="Male">
                        Male
                    </option>
                    <option
                        <?php echo e(old('patient_gender', isset($dataObj) && $dataObj->patient_gender == "Female" ? "Female" : '') == "Female" ? 'selected' : ''); ?>

                        value="Female">
                        Female
                    </option>
                    <input type="hidden" class="form-control <?php $__errorArgs = ['patient_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['patient_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="patient_age" class="form-label col-3 col-sm-3 col-md-4">Age
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
                <input type="text" class="form-control <?php $__errorArgs = ['patient_age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="patient_age" name="patient_age" placeholder="Address"
                    value="<?php echo e(Request::old('patient_age', $dataObj->patient_age ?? '')); ?>" maxlength="2" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                <?php $__errorArgs = ['patient_age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="patient_type_id" class="form-label col-3 col-sm-3 col-md-4">Patient Type
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
            <select
                    class="js-example-basic-single form-control <?php $__errorArgs = ['patient_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="patient_type_id" name="patient_type_id">
                    <option value="" selected>select patient type</option>
                    <?php $__currentLoopData = $patientTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                            <?php echo e(old('patient_type_id', isset($dataObj) && $dataObj->patient_type_id == $type->id ? $type->id : '') == $type->id ? 'selected' : ''); ?>

                            value="<?php echo e($type->id); ?>">
                            <?php echo e($type->name); ?>

                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" class="form-control <?php $__errorArgs = ['patient_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['patient_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </select>
            </div>
        </div>
    </div>
    <div id="Orthodontice_Plan_Area" class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="orthodontice_plan_id" class="form-label col-3 col-sm-3 col-md-4">Orthodontice Plan
                <span class="text-danger">*</span></label>
            <div class="col-9 col-sm-9 col-md-8">
            <select
                    class="js-example-basic-single form-control <?php $__errorArgs = ['orthodontice_plan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="orthodontice_plan_id" name="orthodontice_plan_id">
                    <option value="" selected>select orthodontice plan</option>
                    <?php $__currentLoopData = $orthodonticPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option 
                            <?php echo e(old('orthodontice_plan_id', isset($dataObj) && $dataObj->orthodontice_plan_id == $plan->id ? $plan->id : '') == $plan->id ? 'selected' : ''); ?>

                            value="<?php echo e($plan->id); ?>">
                            <?php echo e($plan->name); ?>

                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" class="form-control <?php $__errorArgs = ['orthodontice_plan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['orthodontice_plan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </select>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-6">
        <div class="form-group row">
            <label for="parent_patient_id" class="form-label col-3 col-sm-3 col-md-4">Parent Patient</label>
            <div class="col-9 col-sm-9 col-md-8">
                <select
                    class="js-example-basic-single form-control <?php $__errorArgs = ['parent_patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="parent_patient_id" name="parent_patient_id">
                    <option value="">Select Parent Patient</option>
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(!isset($dataObj) || $dataObj->id !== $patient->id): ?>
                            <option
                                <?php echo e(old('parent_patient_id', $dataObj->parent_patient_id ?? '') == $patient->id ? 'selected' : ''); ?>

                                value="<?php echo e($patient->id); ?>">
                                <?php echo e($patient->name); ?> (<?php echo e($patient->patient_contact_no); ?>)
                            </option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['parent_patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>


<div class="form-group row">
    <label for="allergen" class="form-label col-3 col-sm-3 col-md-2">Alergy</label>
    <div class="col-9 col-sm-9 col-md-10">
        <?php if(count($alergys)): ?>
            <?php $__currentLoopData = $alergys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allergen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="allergen_ids[]"
                id="allergen_<?php echo e($allergen->id); ?>" value="<?php echo e($allergen->id); ?>"
                <?php echo e(old('patientAlergies', isset($patientAlergies) && $patientAlergies->contains('alergy_id', $allergen->id)) ? 'checked' : ''); ?>>
                <label class="form-check-label" for="allergen_<?php echo e($allergen->id); ?>"><?php echo e($allergen->name); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<div class="form-group row">
    <label for="disease" class="form-label col-3 col-sm-3 col-md-2">Diseases</label>
    <div class="col-9 col-sm-9 col-md-10">
        <?php if(count($diseases)): ?>
            <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="disease_ids[]"
                        id="disease_<?php echo e($disease->id); ?>" value="<?php echo e($disease->id); ?>"
                        <?php echo e(old('patientDiseases', isset($patientDiseases) && $patientDiseases->contains('disease_id', $disease->id) ? 'checked' : '')); ?>>
                    <label class="form-check-label" for="disease_<?php echo e($disease->id); ?>"><?php echo e($disease->name); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>


<?php $__env->startPush('css'); ?>
    <style>
        .select2-container .select2-selection--single {
            height: 38px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $("#isDisplay").on("change", function() {
                var input = this;
                var isChecked = $(input).prop("checked");
                $isDisplayValue = isChecked ? 1 : 0
                $(input).val($isDisplayValue);
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            function toggleOrthodonticPlanArea() {
                const patientTypeId = $('#patient_type_id').val();
                if (patientTypeId === '2') {
                    $('#Orthodontice_Plan_Area').show();
                } else {
                    $('#Orthodontice_Plan_Area').hide();
                }
            }

            // Initial check
            toggleOrthodonticPlanArea();

            // On change event
            $('#patient_type_id').change(function() {
                toggleOrthodonticPlanArea();
            });
        });
    </script>


<!-- <script>
    document.addEventListener('DOMContentLoaded', function () {
        var patientTypeSelect = document.getElementById('patient_type_id');
        const orthoPlanArea = document.getElementById('Orthodontice_Plan_Area');

        // console.log(patientTypeSelect).value;
        // console.log(orthoPlanArea);
        console.log(patientTypeSelect.value);

        // Debugging: Ensure elements are selected
        console.log('Patient Type Select Element:', patientTypeSelect);
        console.log('Orthodontice Plan Area Element:', orthoPlanArea);

        // Check if the elements exist
        if (!patientTypeSelect || !orthoPlanArea) {
            console.error('One or more elements are not found in the DOM.');
            return;
        }

// Ensure the event listener is added correctly
patientTypeSelect.addEventListener('change', function () {
    console.log('Patient type changed:', this.value);
    if (this.value == 1) {
        orthoPlanArea.style.display = 'block';
    } else {
        orthoPlanArea.style.display = 'none';
    }
});

        patientTypeSelect.addEventListener('change', function () {
            console.log('Patient type changed:', this.value);
            if (this.value == 1) {
                orthoPlanArea.style.display = 'block';
            } else {
                orthoPlanArea.style.display = 'none';
            }
        });

        // Check the initial state on page load
        if (patientTypeSelect.value == 1) {
            orthoPlanArea.style.display = 'block';
        } else {
            orthoPlanArea.style.display = 'none';
        }
    });
</script> -->

    <!-- <script>
        // When click radio button yes or no handle
        function checkRadioButton(radio) {
            const patientTypeSelect = document.getElementById('patient_type_id');
            const orthoPlanArea = document.getElementById('Orthodontice_Plan_Area');

            if (patientTypeSelect.value == 1) {
                patientTypeSelect.style.display = '';
                orthoPlanArea.style.display = 'none';
            } else {
                patientTypeSelect.style.display = 'none';
                orthoPlanArea.style.display = '';
            }
        }
    </script> -->
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/patient/body.blade.php ENDPATH**/ ?>