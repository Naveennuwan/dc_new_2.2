<?php $__env->startSection('title', __('Routine Invoice')); ?>

<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar modern-toolbar">
        <div class="row col-12 col-sm-12 col-md-12 align-items-center">
            <div class="col-12 col-sm-5 col-md-6">
                <h6 class="text-muted font-weight-bold modern-toolbar-title toolbar-3d-title"><?php echo e($routeName); ?> Invoice</h6>
            </div>
            <div class="col-12 col-sm-7 col-md-6 text-right">
                <div class="btn-toolbar justify-content-end text-right" role="toolbar" aria-label="Toolbar with button groups">
                    <?php echo $__env->make('components.toolbar', ['showExportButton' => false, 'showSearchButton' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(is_object($patientDetails)): ?>
                    <div class="btn-group" role="group">
                        <button id="invoice-btn" class="modern-btn btn-lime fixed-width-button-130">Invoice</button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-2">
    <div class="card-body">
        <div class="row g-3">
            <!-- Patient -->
            <div class="col-12 col-md-8">
                <label for="patient_id" class="form-label">Patient</label>
                <select
                    class="js-example-basic-single form-control <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="patient_id"
                    name="patient_id"
                >
                    <option value="">Select patient</option>
                    <?php $__currentLoopData = $patientObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($patient->id); ?>"
                            <?php echo e(old('patient_id', $searchingVals['patient_id'] ?? '') == $patient->id ? 'selected' : ''); ?>

                        >
                            <?php echo e($patient->patientType->name[0]); ?>P-<?php echo e($patient->patient_register_id); ?>

                            - <?php echo e($patient->name); ?>

                            - <?php echo e($patient->patient_address); ?>

                            - <?php echo e($patient->patient_contact_no); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Doctor -->
            <div class="col-12 col-md-4">
                <label for="doctor_id" class="form-label">Doctor</label>
                <select
                    class="js-example-basic-single form-control <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="doctor_id"
                    name="doctor_id"
                >
                    <option value="">Select doctor</option>
                    <?php $__currentLoopData = $doctorObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($doctor->id); ?>"
                            <?php echo e(old('doctor_id', $searchingVals['doctor_id'] ?? '') == $doctor->id ? 'selected' : ''); ?>

                        >
                            <?php echo e($doctor->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <?php if($patientDetails): ?>
        <div style="display: flex; justify-content: center; align-Items:center; gap: 10px;">
            <div class="btn-group" role="group">
                <button id="advance-btn" style="width: 200px; height: 40px; font-size: 1rem;" class="modern-btn btn-lime" 
                    data-toggle="modal" data-target="#advanceModal">
                    <i class="fas fa-wallet mr-2"></i>
                    Add Advance
                </button>
            </div>
            <div class="btn-group" role="group">
                <button id="discount-btn"  style="width: 200px; height: 40px; font-size: 1rem;" class="modern-btn btn-lime" 
                    data-toggle="modal" data-target="#discountModal">
                    <i class="fas fa-tag mr-2"></i>
                    Add Discount
                </button>
            </div>
            <div class="btn-group" role="group">
                <button id="next-visit-btn" style="width: 200px; height: 40px; font-size: 1rem;" class="modern-btn btn-peach"
                    data-toggle="modal" data-target="#nextVisitModal">
                    <i class="fas fa-calendar-plus mr-2"></i>
                    Add Next Visit
                </button>
            </div>
            <div class="btn-group" role="group">
                <button id="image-upload-btn" style="width: 200px; height: 40px; font-size: 1rem;" class="modern-btn btn-aqua"
                    data-toggle="modal" data-target="#imageUploadModal">
                    <i class="fas fa-upload mr-2"></i>
                    Upload Image
                </button>
            </div>
            <div class="btn-group" role="group">
                <button id="image-view-btn" style="width: 200px; height: 40px; font-size: 1rem;" class="modern-btn btn-aqua"
                    data-toggle="modal" data-target="#imageViewdModal">
                    <i class="fas fa-eye mr-2"></i>
                    View Images
                </button>
            </div>
        </div>
        <div class="form-row mt-3">
                <div class="form-group col-6 col-sm-6">
                    <label >Age :- </label>
                    <?php echo e($patientDetails->patient_age); ?>

                </div>
                <div class="form-group col-6 col-sm-6">
                    <label >Center :- </label>
                    <?php echo e($patientDetails->center->name); ?>

                </div>
            </div>

            <?php if($patientDetails->orthodonticPlanType): ?>
            <div class="form-row">
                <div class="form-group col-6 col-sm-4">
                    <label ><?php echo e($templateDetails->name); ?> :- <?php echo e($templateDetails->price); ?></label> /=<br/>
                </div>
            </div>
            <?php endif; ?>
            <div class="form-row">
                <?php if(count($alergies)): ?>
                <div class="form-group">
                    <label for="patient_id">Alergies :- </label>
                    <?php $__currentLoopData = $alergies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alergy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($alergy->alergy->name); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="form-row">
                <?php if(count($diseases)): ?>
                <div class="form-group">
                    <label for="patient_id">Disease :- </label>
                    <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($disease->disease->name); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<div class="row">
    <div class="form-group col-6 col-sm-6">
        <?php echo $__env->make('pages.dashboard.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="form-group col-6 col-sm-6">
        <?php echo $__env->make('pages.dashboard.patient_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php echo $__env->make('pages.dashboard.model', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

<!-- Button Clicks -->
<script>
    $(function () {
    // Make sure no duplicate select2 scripts are loaded.
    if (typeof $.fn.select2 === 'undefined') {
        console.error('Select2 is not loaded!');
        return;
    }

    // Optional: destroy if already initialized (prevents double-init issues)
    $('#patient_id').each(function () {
        if ($(this).data('select2')) $(this).select2('destroy');
    });
    $('#doctor_id').each(function () {
        if ($(this).data('select2')) $(this).select2('destroy');
    });

    // Initialize selects explicitly
    $('#patient_id').select2({
        width: '100%',
        placeholder: 'Select patient',
        allowClear: true
    });

    $('#doctor_id').select2({
        width: '100%',
        placeholder: 'Select doctor',
        allowClear: true
    });

    // If you also use the generic class, you can init remaining ones:
    $('.js-example-basic-multiple').not('#patient_id, #doctor_id').select2({ width: '100%' });
    });

    $(document).ready(function () {
        $('#search-btn').on('click', function (e) {
            e.preventDefault();

            const patientEl = document.getElementById('patient_id');
            const doctorEl  = document.getElementById('doctor_id');

            const patientId = patientEl ? patientEl.value : null;
            const doctorId  = doctorEl ? doctorEl.value : null;

            console.log(patientId)
            console.log(doctorId)

            if (!patientId) {
                alert('Please select a patient');
                return;
            }

            let url = `<?php echo e(url('/invoice')); ?>/${patientId}`;

            if (doctorId) {
                url += `/${doctorId}`;
            }

            window.location.href = url;
        });
    });
</script>

<!--Model Submit Button Clicks -->
<script>
    $(document).ready(function() {
        $('#advance-btn').on('click', function() {
            $('#advanceModal').modal('show');
        });
    });

    $(document).ready(function() {
        $('#discount-btn').on('click', function() {
            $('#discountModal').modal('show');
        });
    });
    
    $(document).ready(function() {
        $('#next-visit-btn').on('click', function() {
            $('#nextVisitModal').modal('show');
        });
    });
    
    $(document).ready(function() {
        $('#image-upload-btn').on('click', function() {
            $('#imageUploadModal').modal('show');
        });
    });
    
    $(document).ready(function() {
        $('#image-view-btn').on('click', function() {
            $('#imageViewModal').modal('show');
        });
    });
    
    $(document).ready(function() {
        $('#invoice-btn').on('click', function() {
            $('#invoiceModal').modal('show');
        });
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/dashboard/invoice.blade.php ENDPATH**/ ?>