<?php $__env->startSection('title', __('Patient')); ?>

<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar">
        <div class="row col-12 col-sm-12 col-md-12">
            <div class="col-12 col-sm-5 col-md-6">
            <h6 class="text-muted font-weight-bold modern-toolbar-title toolbar-3d-title">Patient / Create</h6>
            </div>
            <div class="col-12 col-sm-7 col-md-6 text-right">
                <div class="btn-toolbar justify-content-end text-right" role="toolbar" aria-label="Toolbar with button groups">
                    <div class="btn-group mr-2" role="group">
                        <a href="<?php echo e(route('patient.index')); ?>"
                        class="modern-btn btn-azure fixed-width-button-120">Back</a>
                    </div>
                    <div class="btn-group mr-2" role="group">
                    <button id="save-btn" class="modern-btn fixed-width-button-130 btn-lime">Save Changers</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <br />
                        <form method="post" action="<?php echo e(route('patient.store')); ?>" name="addForm" id="addForm"
                            data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-body">
                                    <?php echo $__env->make('pages.patient.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#save-btn').on('click', function() {
                $('#addForm').submit();
            });
        });
    </script>

<script>
    document.addEventListener('DOMContentLoaded', (event) => {
        document.getElementById('isDisplay').checked = true;
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/patient/create.blade.php ENDPATH**/ ?>