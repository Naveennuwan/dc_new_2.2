<form method="POST"
      action="<?php echo e(route('other-payment.store')); ?>"
      class="other-payment-form"
      data-payment-type="<?php echo e($paymentType); ?>">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="payment_type" value="<?php echo e($paymentType); ?>">
    <input type="hidden" name="isSettled" value="0">

    <div class="card-body">
        <div class="form-row">
            <div class="form-group col-sm-6">
                <label>Patient</label>
                <select class="js-example-basic-single form-control <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="patient_id" name="patient_id">
                                        <option value="" selected>select patient</option>
                                        <?php $__currentLoopData = $patientObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(Request::old('patient_id', $searchingVals['patient_id'] ?? '') == $patient->id ? 'selected' : ''); ?> value="<?php echo e($patient->id); ?>">
                                            <?php echo e($patient->patient_register_id); ?> - <?php echo e($patient->name); ?> - <?php echo e($patient->patient_address); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
            </div>

            <div class="form-group col-sm-6">
                <label><?php echo e($label); ?></label>
                <input type="text"
                       name="payment"
                       class="form-control payment-input"
                       maxlength="8"
                       required
                       oninput="this.value=this.value.replace(/[^0-9]/g,'')">
            </div>
        </div>
    </div>
</form>
<?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/dashboard/_form.blade.php ENDPATH**/ ?>