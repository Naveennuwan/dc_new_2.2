<?php $__env->startSection('title', __('Patient')); ?>

<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar">
        <div class="row col-12 col-sm-12 col-md-12">
            <div class="col-12 col-sm-5 col-md-6">
                <h6 class="text-muted font-weight-bold modern-toolbar-title toolbar-3d-title"> Patient / List</h6>
            </div>
            <div class="col-12 col-sm-7 col-md-6 text-right">
                <div class="btn-toolbar justify-content-end text-right" role="toolbar" aria-label="Toolbar with button groups">
                <?php echo $__env->make('components.toolbar', ['showExportButton' => false, 'showSearchButton' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('patient.create')); ?>"
                            class="modern-btn fixed-width-button-130 btn-lime <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('patient-create')): ?> disabled <?php endif; ?>">Create Record</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <form action="<?php echo e(route('patient.search')); ?>" method="post" id="searchForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <p class="text-muted">Search Record...</p>
                        <div>
                            <a href="<?php echo e(route('patient.index')); ?>" class="modern-btn btn-amber fixed-width-button-100">Reset</a>
                        </div>
                    </div>
                    <div class="form-row">
                    <div class="form-group col-6 col-sm-3">
                            <label for="search_name">Name</label>
                            <input type="text" class="form-control" id="search_name" name="search_name"
                                placeholder="Name"
                                value="<?php echo e(Request::old('search_name', $searchingVals['name'] ?? '')); ?>" maxlength="255">
                        </div>
                        <div class="form-group col-6 col-sm-2">
                            <label for="search_name">Phone No.</label>
                            <input type="text" class="form-control" id="patient_contact_no" name="patient_contact_no"
                                placeholder="Phone No."
                                value="<?php echo e(Request::old('patient_contact_no', $searchingVals['patient_contact_no'] ?? '')); ?>" maxlength="255">
                        </div>
                        <div class="form-group col-12 col-sm-3">
                            <label for="search_patient_type">Type</label>
                                <select
                                    class="js-example-basic-single form-control" id="search_patient_type" name="search_patient_type">
                                    <option value="" selected>select type</option>
                                    <?php $__currentLoopData = $patientTypeObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            <?php echo e(Request::old('patient_type_id', $searchingVals['patient_type_id'] ?? '') == $type->id ? 'selected' : ''); ?>

                                            value="<?php echo e($type->id); ?>"> 
                                            <?php echo e($type->name); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        </div>
                        <div class="form-group col-12 col-sm-4">
                            <label for="date_range">Date Range</label>
                            <div class="input-group">
                                <input type="date" class="form-control" id="start_date" name="start_date" 
                                value="<?php echo e(Request::old('start_date', $searchingVals['start_date'] ?? '')); ?>" placeholder="Start Date">
                                <span class="input-group-text">to</span>
                                <input type="date" class="form-control" id="end_date" name="end_date" 
                                value="<?php echo e(Request::old('end_date', $searchingVals['end_date'] ?? '')); ?>" placeholder="End Date">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <br>
    <div class="">
        <form action="<?php echo e(route('patient.export')); ?>" method="post" id="exportForm">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive" id="table-div">
                        <table  id="dataTable"  class="table">
                            <thead class="thead-dark">
                                <tr>
                                <th scope="col"><input type="checkbox" id="checkAll"></th>
                                <th scope="col" style="width:10%">Reg. No</th>
                                <th scope="col" style="width:20%">Name</th>
                                <th scope="col" style="width:15%">Contact No</th>
                                <th scope="col" style="width:10%">Type</th>
                                <th scope="col">Display</th>
                                <th scope="col" style="width:25%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><input type="checkbox" class="checkSingle" id="check_id" name="check_id[]" value="<?php echo e($row->id); ?>"></th>
                                    <td><?php echo e($row->patientType->name[0]); ?>P-<?php echo e($row->patient_register_id); ?></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->patient_contact_no); ?></td>
                                    <td><?php if($row->patient_type_id === 1): ?>
                                        R T P
                                        <?php elseif($row->patient_type_id === 2): ?>
                                        O T P
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($row->created_at->format('Y-m-d')); ?></td>
                                    <td class="row">
                                        <a href="<?php echo e(route('patient.edit', $row->id)); ?>"
                                        class="modern-btn btn-lime fixed-width-button-100 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('patient-edit')): ?> disabled <?php endif; ?>">
                                            <i class="fas fa-pencil" title="Edit"></i>
                                            Edit
                                        </a>
                                        <a href="<?php echo e(route('patient.show', $row->id)); ?>"
                                        class="modern-btn btn-coral fixed-width-button-100 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('patient-delete')): ?> disabled <?php endif; ?>">
                                            <i class="fas fa-trash" title="Delete"></i>
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .select2-container .select2-selection--single {
            height: 38px;
        }

        .row a {
            margin-right: 8px;
        }

        .row a:last-child {
            margin-right: 0;
        }
        
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Check All functionality
            document.getElementById('checkAll').addEventListener('change', function() {
                var checkboxes = document.getElementsByClassName('checkSingle');
                for (var i = 0; i < checkboxes.length; i++) {
                    checkboxes[i].checked = this.checked;
                }
            });

            // Individual checkbox event handling
            var checkboxes = document.getElementsByClassName('checkSingle');
            for (var i = 0; i < checkboxes.length; i++) {
                checkboxes[i].addEventListener('change', function() {
                    document.getElementById('checkAll').checked = false;
                });
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#search-btn').on('click', function() {
                $('#searchForm').submit();
            });

            $('#export-btn').on('click', function() {
                $('#exportForm').submit();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/patient/index.blade.php ENDPATH**/ ?>