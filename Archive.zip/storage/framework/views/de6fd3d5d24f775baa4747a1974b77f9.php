<nav class="navbar">
    <div class="navbar-left">
        <a href="/" class="logo">Power Smile</a>
    </div>

    <div class="navbar-menu ">
        <div class="drop-down">
            <button class="dropbtn">
                Master Control
                &nbsp; <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('center.index')); ?>">Center</a>
                <a href="<?php echo e(route('doctor.index')); ?>">Doctor</a>
                <a href="<?php echo e(route('drug-frequency.index')); ?>">Drug Frequency</a>
                <a href="<?php echo e(route('leave-request.index')); ?>">Leave Request</a>
            </div>
        </div>
        
        <div class="drop-down">
            <button class="dropbtn">
                Products
                &nbsp; <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('brand.index')); ?>">Brand</a>
                <a href="<?php echo e(route('category.index')); ?>">Category</a>
                <a href="<?php echo e(route('product.index')); ?>">Products</a>
                <a href="<?php echo e(route('product-type.index')); ?>">Product Types</a>
                <a href="<?php echo e(route('supplier.index')); ?>">Supplier</a>
            </div>
        </div>
        
        <div class="drop-down">
            <button class="dropbtn">
                Patient
                &nbsp; <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('alergy.index')); ?>">Alergy</a> 
                <a href="<?php echo e(route('disease.index')); ?>">Disease</a>
                <a href="<?php echo e(route('patient.index')); ?>">Patient</a>
                <a href="<?php echo e(route('patient-type.index')); ?>">Patient Types</a>
            </div>
        </div>
        
        <div class="drop-down">
            <button class="dropbtn">
                Reports
                &nbsp; <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('medical.index')); ?>">Medical Report</a>
                <a href="<?php echo e(route('leave.index')); ?>">Leave Request Letter</a>
                <a href="<?php echo e(route('reports.index')); ?>">Other reports</a>
            </div>
        </div>
        
        <div class="drop-down">
            <button class="dropbtn">
                SMS
                &nbsp; <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            </div>
        </div>
        
        <div class="drop-down">
            <button class="dropbtn">
                Template
                &nbsp; <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('laboratory-expense.index')); ?>">Laboratory Expense</a>
                <a href="<?php echo e(route('orthodontic-plan.index')); ?>">Orthodontic Plan</a>
                <a href="<?php echo e(route('template-type.index')); ?>">Template Type</a>
                <a href="<?php echo e(route('template-category.index')); ?>">Template Category</a>
                <a href="<?php echo e(route('template.index')); ?>">Templates</a>
            </div>
        </div>

        <div class="navbar-right">
            <div class="online">
                <img src="<?php echo e(asset('images/user-4.png')); ?>" class="nav-profile-img dropdown" onclick="toggleMenu()">
            </div>

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="<?php echo e(asset('images/user-4.png')); ?>">
                        <?php echo e(Auth::user()->name ?? ''); ?>

                    </div>
                    <hr>
                    <hr>
                    <a href="#" class="sub-menu-link">
                        <img src="<?php echo e(asset('images/profile.png')); ?>">
                        <p>Edit Profile</p>
                    </a>
                    <a href="<?php echo e(url('/logout')); ?>" class="sub-menu-link"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <img src="<?php echo e(asset('images/logout.png')); ?>">
                        <p>Logout</p>
                    </a>
                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>


</nav>
<?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/components/nav.blade.php ENDPATH**/ ?>