<?php $__env->startSection('title', __('Medical Certificates')); ?>

<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar">
        <div class="row col-12 col-sm-12 col-md-12">
            <div class="col-12 col-sm-5 col-md-6">
                <h6 class="text-muted font-weight-bold modern-toolbar-title toolbar-3d-title">Patient / Medical Certificates / List</h6>
            </div>
            <div class="col-12 col-sm-7 col-md-6 text-right">
                <div class="btn-toolbar justify-content-end text-right" role="toolbar" aria-label="Toolbar with button groups">
                <?php echo $__env->make('components.toolbar', ['showExportButton' => false, 'showSearchButton' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('medical.create')); ?>"
                            class="modern-btn btn-lime fixed-width-button-120 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('center-create')): ?> disabled <?php endif; ?>">Create Record</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <form action="<?php echo e(route('medical.search')); ?>" method="post" id="searchForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <p class="text-muted">Search Record...</p>
                        <div>
                            <a href="<?php echo e(route('medical.index')); ?>" class="modern-btn btn-amber fixed-width-button-100">Reset</a>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-12 col-sm-2">
                            <label for="search_id">Id</label>
                            <input type="text" class="form-control" id="search_id" name="search_id"
                                placeholder="Id"
                                value="<?php echo e(Request::old('search_id', $searchingVals['id'] ?? '')); ?>" maxlength="255">
                        </div>
                        <div class="form-group col-12 col-sm-5">
                            <label for="search_name">Name</label>
                            <input type="text" class="form-control" id="search_name" name="search_name"
                                placeholder="Name"
                                value="<?php echo e(Request::old('search_name', $searchingVals['name'] ?? '')); ?>" maxlength="255">
                        </div>
                        <div class="form-group col-12 col-sm-2 col-md-2">
                            <label for="search_display">Display</label>
                            <select class="js-example-basic-single form-control" id="search_display" name="search_display">
                                <option value="" selected>All</option>
                                <option value="1"
                                    <?php echo e(Request::old('search_display', $searchingVals['isDisplay'] ?? '') == '1' ? 'selected' : ''); ?>>
                                    Display</option>
                                <option value="0"
                                    <?php echo e(Request::old('search_display', $searchingVals['isDisplay'] ?? '') == '0' ? 'selected' : ''); ?>>
                                    Hidden</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <br>
    <div class="">
        <form action="<?php echo e(route('medical.export')); ?>" method="post" id="exportForm">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive" id="table-div">
                        <table  id="dataTable"  class="table">
                            <thead class="thead-dark">
                                <tr>
                                <th scope="col"><input type="checkbox" id="checkAll"></th>
                                <th scope="col" style="width:40%">Name</th>
                                <th scope="col" style="width:30%">Surgeon</th>
                                <th scope="col" style="width:30%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><input type="checkbox" class="checkSingle" id="check_id" name="check_id[]" value="<?php echo e($row->id); ?>"></th>
                                    <td><?php echo e($row->patient->name); ?></td>
                                    <td><?php echo e($row->doctor->name); ?></td>
                                    <td class="row">
                                        <a href="<?php echo e(route('medical.report', $row->id)); ?>"
                                        class="modern-btn btn-lime fixed-width-button-100 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('center-edit')): ?> disabled <?php endif; ?>">
                                            <i class="fas fa-download" title="Report"></i>
                                            Download
                                        </a>
                                        <a href="<?php echo e(route('medical.show', $row->id)); ?>"
                                        class="modern-btn btn-coral fixed-width-button-100 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('center-delete')): ?> disabled <?php endif; ?>">
                                            <i class="fas fa-trash" title="Delete"></i>
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .select2-container .select2-selection--single {
            height: 38px;
        }

        .row a {
            margin-right: 8px;
        }

        .row a:last-child {
            margin-right: 0;
        }

        
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Check All functionality
            document.getElementById('checkAll').addEventListener('change', function() {
                var checkboxes = document.getElementsByClassName('checkSingle');
                for (var i = 0; i < checkboxes.length; i++) {
                    checkboxes[i].checked = this.checked;
                }
            });

            // Individual checkbox event handling
            var checkboxes = document.getElementsByClassName('checkSingle');
            for (var i = 0; i < checkboxes.length; i++) {
                checkboxes[i].addEventListener('change', function() {
                    document.getElementById('checkAll').checked = false;
                });
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#search-btn').on('click', function() {
                $('#searchForm').submit();
            });

            $('#export-btn').on('click', function() {
                $('#exportForm').submit();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/medical/index.blade.php ENDPATH**/ ?>