<?php $__env->startSection('title', __('Monthly Report')); ?>
            <?php
            $totalTreatement = 0;
            ?>

<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar">
        <div class="row col-12 col-sm-12 col-md-12">
            <div class="col-12 col-sm-5 col-md-6">
            <h6 class="text-muted font-weight-bold modern-toolbar-title toolbar-3d-title">Other Reports / Monthly Report</h6>
            </div>
            <div class="col-12 col-sm-7 col-md-6 text-right">
                <div class="btn-toolbar justify-content-end text-right" role="toolbar" aria-label="Toolbar with button groups">
                    <div class="btn-group mr-2" role="group">
                        <a href="<?php echo e(route('reports.index')); ?>"
                        class="modern-btn btn-azure fixed-width-button-120">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3 class="mb-4 fw-bold">Monthly Summary Dashboard</h3>

    
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card dashboard-card text-white bg-primary">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="card-title">Total Patients</div>
                        <div class="card-value"><?php echo e($totalPatients); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card dashboard-card text-white bg-success">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="card-title">Routine Patients</div>
                        <div class="card-value"><?php echo e($totalRoutinePatients); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card dashboard-card text-white bg-info">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="card-title">Orthodontic Patients</div>
                        <div class="card-value"><?php echo e($totalOrthodonticPatients); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-teeth"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <?php
        $totalsByType = $monthlyOtherPayments->groupBy('payment_type')->map(function($group){
            return $group->sum('payment');
        });
        ?>

        <?php $__currentLoopData = $totalsByType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mb-4">
            <div class="card dashboard-card text-white bg-warning">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="card-title"><?php echo e($type ?? 'Unknown'); ?> Payments</div>
                        <div class="card-value"><?php echo e(number_format($total,2)); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



    <h5 class="mt-5">Routing Treatments</h5>
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Template</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $getRoutingTreatmentsMonthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($treatment->template->name ?? 'Unknown'); ?></td>
                <td><?php echo e($treatment->total ?? 'Unknown'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">No treatments recorded today.</td>
            </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="table-secondary">
                <td colspan="2" class="text-end"><strong>Total :</strong></td>
                <td><strong><?php echo e(number_format($getRoutingTreatmentsMonthly->sum('total'), 2)); ?></strong></td>
            </tr>
        </tfoot>
    </table>

    <h5 class="mt-5">Orthodontic Treatments</h5>
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Template</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $getOrthodonticTreatmentsMonthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($treatment->template->name ?? 'Unknown'); ?></td>
                <td><?php echo e($treatment->total ?? 'Unknown'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">No treatments recorded today.</td>
            </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="table-secondary">
                <td colspan="2" class="text-end"><strong>Total :</strong></td>
                <td><strong><?php echo e(number_format($getOrthodonticTreatmentsMonthly->sum('total'), 2)); ?></strong></td>
            </tr>
        </tfoot>
    </table>

    <h5 class="mt-5">Payments</h5>
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Patient</th>
                <th>Treatement Name</th>
                <th>Treatement Value</th>
                <th>Payment</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $getPaymentMonthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $price = 0;

                $treatment = $payment->savedTreatment;

                if ($treatment && $treatment->priceLevels->count() === 1) {
                    $price = $treatment->priceLevels->first()->price;

                } elseif ($treatment && $treatment->priceLevels->count() >= 2) {

                    $patient = $treatment->patient;

                    $nextPrice = $treatment->priceLevels
                        ->sortByDesc('effective_from')
                        ->first(function ($item) use ($patient) {
                            return $item->effective_from->lte($patient->created_at);
                        });

                    $price = $nextPrice ? $nextPrice->price : 0;
                }
                $totalTreatement += $price;
            ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($payment->savedTreatment->patient->name ?? 'Unknown'); ?></td>
                <td><?php echo e($payment->savedTreatment->template->name ?? 'Unknown'); ?></td>
                <td><?php echo e(number_format($price, 2) ?? 'Unknown'); ?></td>
                <td><?php echo e($payment->payment ?? 'Unknown'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">No treatments recorded today.</td>
            </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="table-secondary">
                <td colspan="3" class="text-end"><strong>Total :</strong></td>
                <td><strong><?php echo e(number_format($totalTreatement, 2)); ?></strong></td>
                <td><strong><?php echo e(number_format($getPaymentMonthly->sum('payment'), 2)); ?></strong></td>
            </tr>
            <tr class="table-secondary">
                <td colspan="4" class="text-end"><strong>Profit :</strong></td>
                <td><strong><?php echo e(number_format($getPaymentMonthly->sum('payment') - $totalTreatement, 2)); ?></strong></td>
            </tr>
        </tfoot>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>

.dashboard-card{
    border-radius:15px;
    border:none;
    box-shadow:0 4px 15px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.dashboard-card:hover{
    transform: translateY(-5px);
    box-shadow:0 8px 20px rgba(0,0,0,0.2);
}

.card-icon{
    font-size:30px;
    opacity:0.8;
}

.card-title{
    font-size:16px;
    font-weight:600;
}

.card-value{
    font-size:32px;
    font-weight:bold;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/reports/monthly.blade.php ENDPATH**/ ?>