<?php $__env->startSection('title', __('Supplier')); ?>

<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar">
        <div class="row col-12 col-sm-12 col-md-12">
            <div class="col-12 col-sm-5 col-md-6">
                <h6 class="text-muted font-weight-bold modern-toolbar-title toolbar-3d-title">Other Reports</h6>
            </div>
            <div class="col-12 col-sm-7 col-md-6 text-right">
                <div class="btn-toolbar justify-content-end text-right" role="toolbar" aria-label="Toolbar with button groups">
                    <?php echo $__env->make('components.toolbar', ['showExportButton' => false,'showSearchButton' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <h2 class="mb-4">Sales Reports</h2>

        <div class="row">

            <div class="col-md-4 mb-3">
                <a href="<?php echo e(route('reports.daily')); ?>" class="btn btn-primary w-100">
                    Daily Sales Report
                </a>
            </div>

            <div class="col-md-4 mb-3">
                <a href="<?php echo e(route('reports.monthly')); ?>" class="btn btn-success w-100">
                    Monthly Sales Report
                </a>
            </div>

            <div class="col-md-4 mb-3">
                <a href="<?php echo e(route('reports.doctor')); ?>" class="btn btn-info w-100">
                    Doctor Revenue Report
                </a>
            </div>

            <div class="col-md-4 mb-3">
                <a href="<?php echo e(route('reports.treatment')); ?>" class="btn btn-warning w-100">
                    Treatment Sales Report
                </a>
            </div>

            <div class="col-md-4 mb-3">
                <a href="<?php echo e(route('reports.center')); ?>" class="btn btn-secondary w-100">
                    Center Sales Report
                </a>
            </div>

            <div class="col-md-4 mb-3">
                <a href="<?php echo e(route('reports.outstanding')); ?>" class="btn btn-danger w-100">
                    Outstanding Payments
                </a>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .select2-container .select2-selection--single {
            height: 38px;
        }
        
        .row a {
            margin-right: 8px;
        }

        .row a:last-child {
            margin-right: 0;
        }

        
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Check All functionality
            document.getElementById('checkAll').addEventListener('change', function() {
                var checkboxes = document.getElementsByClassName('checkSingle');
                for (var i = 0; i < checkboxes.length; i++) {
                    checkboxes[i].checked = this.checked;
                }
            });

            // Individual checkbox event handling
            var checkboxes = document.getElementsByClassName('checkSingle');
            for (var i = 0; i < checkboxes.length; i++) {
                checkboxes[i].addEventListener('change', function() {
                    document.getElementById('checkAll').checked = false;
                });
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#search-btn').on('click', function() {
                $('#searchForm').submit();
            });

            $('#export-btn').on('click', function() {
                $('#exportForm').submit();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/naveennuwan/Documents/GitHub/dc_new_2.2/resources/views/pages/reports/index.blade.php ENDPATH**/ ?>