<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="slide navbar style.css">
    <link rel="stylesheet" href="./css/login.css">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <title>Power Smile | Login</title>
</head>


<style>

body{
	margin: 0;
	padding: 0;
	display: flex;
	justify-content: center;
	align-items: center;
	min-height: 100vh;
	font-family: 'Jost', sans-serif;
	background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
}

img {
	width: auto;
	max-width: 100%;
}

.img-box,
.text-box {
	display: flex;
	justify-content: center;
	align-items: center;
}

.main{
	width: 350px;
	height: 500px;
	background: red;
	overflow: hidden;
	background: url("https://doc-08-2c-docs.googleusercontent.com/docs/securesc/68c90smiglihng9534mvqmq1946dmis5/fo0picsp1nhiucmc0l25s29respgpr4j/1631524275000/03522360960922298374/03522360960922298374/1Sx0jhdpEpnNIydS4rnN4kHSJtU1EyWka?e=view&authuser=0&nonce=gcrocepgbb17m&user=03522360960922298374&hash=tfhgbs86ka6divo3llbvp93mg4csvb38") no-repeat center/ cover;
	border-radius: 10px;
	box-shadow: 5px 20px 50px #000;
}

label{
	color: #fff;
	font-size: 2.3em;
	justify-content: center;
	display: flex;
	margin: 60px;
	font-weight: bold;
	cursor: pointer;
	transition: .5s ease-in-out;
}

input{
	width: 60%;
	height: 20px;
	background: #e0dede;
	justify-content: center;
	display: flex;
	margin: 20px auto;
	padding: 10px;
	border: none;
	outline: none;
	border-radius: 5px;
}

.button{
	width: 60%;
	height: 40px;
	margin: 10px auto;
	justify-content: center;
	display: block;
	color: #fff;
	background: #573b8a;
	font-size: 1em;
	font-weight: bold;
	margin-top: 20px;
	outline: none;
	border: none;
	border-radius: 5px;
	transition: .2s ease-in;
	cursor: pointer;
}

button:hover{
	background: #6d44b8;
}

.login{
	height: 460px;
	background: #eee;
	border-radius: 60% / 10%;
	transform: translateY(-100px);
	transition: .8s ease-in-out;
}

.login label{
	color: #573b8a;
	transform: scale(.6);
}

</style>
<body>
	<div class="main"> 
        <div class="img-box">
            <img src="{{ asset('images/logo2.png') }}" alt="logo" class="">
        </div>
        <div class="login">
            <form method="post" class="form" action="{{ route('login') }}">
                @csrf
                
                <label for="chk" aria-hidden="true">Login</label>
                
                <input id="email" type="email" placeholder="Enter Email"
				class="form-control @error('email') is-invalid @enderror" name="email"
				value="{{ old('email') }}" required autocomplete="email" autofocus>

				<input id="password" type="password" placeholder="Enter Password"
				class="form-control @error('password') is-invalid @enderror" name="password" required
				autocomplete="current-password">
                
                <input class="button"  id="submit" type="submit" value="Log in" class="submit">
            </form>
        </div>
	</div>
</body>

</html>